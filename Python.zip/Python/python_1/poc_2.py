while True:
    print('1. Create Student')
    print('2. Update Student details')
    print('3. Delete Student')
    print('4. Exit')
    choice = int(input('Enter your choice [1-4] : '))
    if choice == 1:
        name = input("Enter student's name : ")
        stud_id = int(input("Enter student's Id : "))
        age = int(input("Enter student's age : "))
        studentDb = [{'name': name, 'stud_id': stud_id, 'age': age}]
    elif choice == 2:
        
    elif choice == 3:
        
    else:
        break
