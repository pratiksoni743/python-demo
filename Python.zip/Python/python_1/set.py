l = [12, 1, 3, 4, 5, 1, 4, 5, 3, 2, 5, 1, 6, 4, 3,
     4, 5, 6, 2, 1, 2, 4, 5, 6, 2, 2, 1, 1, 1, 4]
print(l)
print(type(l))

s = set(l)
print(s)
print(type(s))
