x = 10

memory = id(x)

print(memory)

print(hex(memory))