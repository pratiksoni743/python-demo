list1 = [1, 3, 'data', 5.7, [10, 20]]
print(list1)

list1.append('new')
print(list1)

list1.extend('new')
print(list1)

list1.pop()
print(list1)

print(list1.index('data'))