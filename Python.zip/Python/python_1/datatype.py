print('Hello World 1')

x = 10
print('value of x : ', x)

print(type(x))

cars = 100
drivers = 80

print('There are', cars, 'cars and', drivers, 'drivers')
print('There are {} cars and {} drivers'.format(cars, drivers))
print('There are %d cars and %d drivers'%(cars, drivers))

# this is a comment
print(x ** 2)  # raise to 2 function

# multiline comment
# this is multiline comment

age = input('Enter your age : ')
print(type(age))

age_no = int(age)
print(type(age_no))
