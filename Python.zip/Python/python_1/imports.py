import math
import time
import random

x = 25
print(math.sqrt(x))

time.sleep(2)

print(random.randint(1, 100))

s = "string"
print(dir(s))
