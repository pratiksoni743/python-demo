d = {'a': 12, 'b': 40, 'c': 71}
print(d)
print(type(d))

print(d.pop('a'))
print(d)

d.clear()
print(d)