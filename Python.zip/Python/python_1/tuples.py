t = (3, 4.5, False, 'data', 35)

print(t)
print(type(t))

# tuple are immutable

tp = ((3, 4.5), False, ('data', 35))

for i in range(len(tp)):
    if isinstance(tp[i], tuple):
        print(i, ':', tp[i])