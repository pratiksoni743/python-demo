num = int(input('Enter a number to find its factorial : '))
for i in range(1, num):
    num = i * num

print(num)

no_vaccine = True
for i in range(3):
    print('take precautions')
    check = input('Is vaccine available (y/n): ')
    if(check == 'y'):
        print("Hooray!!")
        break
else: # else part of for loop. Will be executed if for loop is not broken
    print("for loop didn't break")
print("outside for loop")


