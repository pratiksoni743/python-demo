l = ["python", "is", "fun"]
print(l)

m = list(map(str.upper, l))
print(m)


