l = [x for x in range(10)]
print(l)

l = [x for x in range(10) if x % 2 == 0]
print(l)

t = (45, 77, 109)

d = { i:t[i] for i in range(len(t)) }
print(d)

d = { t.index(i):i for i in t }
print(d)

print(t[::-1])