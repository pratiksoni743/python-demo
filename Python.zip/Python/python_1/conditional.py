x = 10
if x == 10:
    print('x is 10')
    print('end of if block')
    y = x/2
    if y == 5:
        print('y is five')
else:
    print('x is not 10')
    print('End of else block')


invest = 100
income = 80
if invest > income:
    print("Loss")
elif invest == income:
    print("None")
else:
    print("Profit")
