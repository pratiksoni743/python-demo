def greet(name, age = 5):
    print("Hello", name, "!! You are", age, "years old")

inp_name = input("Enter name : ")
inp_age = input("Enter age : ")
greet(inp_name, inp_age)
greet(inp_name)

# functions with n arguements
def arg_fun(*details):
    print(details)
    print("Name : ", details[0])
    print("Age : ", details[1])
    print("City : ", details[2])

arg_fun("Pratik", 25, "Pune")