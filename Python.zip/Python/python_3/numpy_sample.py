import numpy as np
import pandas as pd
import matplotlib.pyplot as plt

lst = [1,2,3]
print(lst * 2)