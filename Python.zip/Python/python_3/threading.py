import threading
import time

def thread_func(*args, **kwargs):
    print('func cal by thread')
    time.sleep(5)
    print('thread')
    time.sleep(1)
    print('thread')
    time.sleep(2)
    print('thread')


thr = threading.Thread(target=thread_func, args=(1,))

thr.start()
print('main function')
