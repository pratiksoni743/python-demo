import sys, os

sys.stdout = open('printFile.txt', 'w+')

def enablePrint():
    sys.stdout = sys.__stdout__

print('Print Overridden')
print('Printed in File')
enablePrint()
print('Console Print')