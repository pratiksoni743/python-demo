import sqlite3 

db = sqlite3.connect('D:/L&D/InternalTrainings/Python/python_3/Employee')
cursor = db.cursor()
cursor.execute('CREATE TABLE emp1 (name VARCHAR(20), id INT , salary INT, year INT)')
cursor.execute("INSERT INTO emp1 values('Pratik', 1001, 12000, 2018)")
cursor.execute('select * from emp1')
