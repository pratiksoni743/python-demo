import pymongo

mongoClient = pymongo.MongoClient()
print(type(mongoClient)) 

db = mongoClient['Python_Db']

collection = db.training

collection.insert_one({'Name' : 'Pratik'})