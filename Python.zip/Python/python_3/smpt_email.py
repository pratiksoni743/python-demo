import smtplib

s = smtplib.SMTP('email server', 587)

s.starttls()

send = 'pratik.soni@gmail.com'